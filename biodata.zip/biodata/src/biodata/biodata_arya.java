import java.util.Scanner;

public class biodata_arya {
    public static void main (String[] args) {
        Scanner input = new Scanner (System.in);
        
        String nama;
        String kelas;
        String sekolah;
        String ttl;
        String alamat;
        String hoby;
        
        System.out.print ("Masukkan Nama...\n");
        nama = input.nextLine ();
        System.out.print ("Masukkan Kelas...\n");
        kelas = input.nextLine ();
        System.out.print ("Masukkan Sekolah...\n");
        sekolah = input.nextLine ();
        System.out.print ("Masukkan Tempat Tanggal Lahir...\n");
        ttl = input.nextLine ();
        System.out.print ("Masukkan Alamat...\n");
        alamat = input.nextLine ();
        System.out.print ("Masukkan Hobby...\n");
        hoby = input.nextLine ();
        
        System.out.println("=====BIODATA=====\n");
        System.out.println("Nama                        :" + nama);
        System.out.println("Kelas                       :" + kelas);
        System.out.println("sekolah                     :" + sekolah);
        System.out.println("Tempat Tanggal Lahir        :" + ttl);
        System.out.println("Hoby                        :" + hoby);
    }
}